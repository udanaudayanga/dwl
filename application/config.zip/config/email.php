<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['wordwrap'] = TRUE;
$config['protocol'] = 'smtp';
$config['smtp_port'] = '587';//need to change; Mandrill: 587
$config['smtp_host'] = 'smtp.mandrillapp.com';//need to change; Mandrill: smtp.mandrillapp.com
$config['smtp_user'] = "DWLC";//need to change
$config['smtp_pass'] = "uKZmJj5UBEULsDnMR9HPkQ";//need to change
$config['smtp_timeout'] = "30";
//$config['charset'] = 'utf-8';
//$config['protocol'] = 'smtp';
//$config['smtp_host'] = 'mail.drsweightloss.center';
//$config['smtp_port'] = '25';
//$config['smtp_user'] = 'info@drsweightloss.center';
//$config['smtp_pass'] = 'Info@drswlc';
//$config['charset'] = 'utf-8';
//$config['mailtype'] = 'html';