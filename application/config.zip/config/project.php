<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * From Email
 */
$config['from_email'] = "mandrill@growmydentistpractice.com";
$config['from_name'] = "DWL Center";

/**
 * Location IP alert
 */
$config['location_update'] = "udanaudayanga@gmail.com,s.abiancar@gmail.com";

/**
 * Email from
 */
$config['app_email'] = "noreply@drsweightloss.center";
$config['app_email_name'] = "DWL Center";

/**
 * Referral product 
 */
$config['referral_pro_id'] = 75;

/**
 * Free product for new registrations
 */
$config['free_pro_for_visit'] = 6;

/**
 * Allowed zero priced products
 */
$config['allow_free_pros'] = array(6,68,63,69);

/**
 * Few cat ids
 */
$config['single_injections_cat'] = 3;
$config['visit_cat'] = array(4,10);
$config['medication_cat'] = 11;
$config['injection_cats'] = array(3,20);
$config['service_cat'] = 22;
$config['bulk_visit_pp'] = 4;
/**
 * meds for ids
 */
$config['meds_for_id'] = array(19=>37,20=>30,21=>15,22=>'DI');
$config['meds_info'] = array(
                            37 => array('ndc'=>'61939-810-10','med'=>'Phentermine HCL 37.5mg TAB','mfg'=>'Mikah Pharma'),
                            30 => array('ndc'=>'00527-1310-10','med'=>'Phentermine HCL 30 mg CAP','mfg'=>'Lannett Co. Inc.'),
                            15 => array('ndc'=>'00527-1742-10','med'=>'Phentermine HCL 15 mg CAP','mfg'=>'Lannett Co. Inc.'),
                            "DI" => array('ndc'=>'10702-0044-01','med'=>'Diethylproprion HCL 25 mg TAB','mfg'=>'KVK Tech, Inc.')
                            );

/**
 * Meds/Inj usage report
 */
$config['injmeds'] = array(
                            "med1" => "37.5mg",
                            "med2" => "30mg",
                            "med3" => "15mg",
                            "med4" => "DI",
                            "inj1" => "B-12 0.4cc",
                            "inj2" => "B-12 1cc",
                            "inj3" => "Lipogen",
                            "inj4" => "Ultraburn"
                          );

$config['meds_pro'] = array(
                            "19" => "med1",
                            "20" => "med2",
                            "21" => "med3",
                            "22" => "med4"
                          );
$config['inj_pro'] = array(
                            "5" => "inj1",
                            "18" => "inj3",
                            "41" => "inj4"
                          );

/**
 * suppliment packs
 */
$config['spacks'] = array(1=>86,2=>87,4=>88);

/**
 * phone no and fax
 */
$config['phone'] = '727-412-8208';
$config['fax'] = '727-999-2000';

/**
 * set color codes
 */
//$config['colors'] = array(0 => '#00AF33',1 => '#808000',2 => '#CD5555',3 => '#FF6347',4 => '#FFB00F',5 => '#9AC0CD',6 => '#4876FF',7 => '#FF3E96',8 => '#EE00EE',9 => '#A9A9A9',10 => '#DB9370',11 => '#CECC15',12 => '#FFFF7E',13=>'#C0C0C0',14=>'#00FFFF',15=>'#728C00',16=>'#9CB071',17=>'#EDDA74',18=>'#FFE5B4',19=>'#FFA62F',20=>'#7F462C');
$config['colors'] = array(0=>array(0=>'#1aa4d5',1=>'#22c8f9',2=>'#75dbf9'),1=>array(0=>'#d3831f',1=>'#fda929',2=>'#ffc873'));